import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-bill',
  templateUrl: './user-bill.component.html',
  styleUrls: ['./user-bill.component.css']
})
export class UserBillComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
