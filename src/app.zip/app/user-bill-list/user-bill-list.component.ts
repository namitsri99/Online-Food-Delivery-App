import { Component, OnInit } from '@angular/core';
import { Bill } from '../model/bill';
import { BillService } from '../service/bill.service';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-user-bill-list',
  templateUrl: './user-bill-list.component.html',
  styleUrls: ['./user-bill-list.component.css']
})
export class UserBillListComponent implements OnInit {

  userBills : Bill[];
  err : string;
  cid: number;
  constructor(private billService : BillService ,private loginService : LoginService) { }

  ngOnInit(): void {
    this.billService.getBillsByCustomer(this.loginService.currentCustomer.customerId).subscribe(
      (data) =>{this.userBills = data; console.log(data);},
      (err) => {console.log (err); this.err = "Sorry. Unable to retrieve data"}
    );
  }

}