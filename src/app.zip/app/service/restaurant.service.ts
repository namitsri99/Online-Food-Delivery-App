import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Restaurant } from '../model/restaurant';

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {

  restaurantsApi:string;

  constructor(private httpClient : HttpClient) { 
    this.restaurantsApi="http://localhost:8082/restaurants";
  }

  getAll() : Observable<Restaurant[]>{
    return this.httpClient.get<Restaurant[]>(this.restaurantsApi);
   
  }
  getById(rid:number) : Observable<Restaurant>{
    return this.httpClient.get<Restaurant>(`${this.restaurantsApi}/${rid}`);

  }

  getResByItem(itemName : string) : Observable<Restaurant[]>{
    return this.httpClient.get<Restaurant[]>(`${this.restaurantsApi}/item/${itemName}`);
  }

  deleteById(rid:number) : Observable<void> {
    return this.httpClient.delete<void>(`${this.restaurantsApi}/${rid}`);
  }
  add(restaurant : Restaurant) :Observable <Restaurant>{
    return this.httpClient.post<Restaurant>(this.restaurantsApi,restaurant);
  }

  update(restaurant :Restaurant) : Observable<Restaurant>{
    return this.httpClient.put<Restaurant>(this.restaurantsApi,restaurant);
  }
}