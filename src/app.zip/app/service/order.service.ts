import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Order } from '../model/order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  orderApi: string;

  constructor(private httpClient: HttpClient) {
    this.orderApi = "http://localhost:8082/orders";
  }

  getAll(): Observable<Order[]>{
     return this.httpClient.get<Order[]>(this.orderApi)
  }

  getById(oid: number): Observable<Order> {
    return this.httpClient.get<Order>(`${this.orderApi}/${oid}`);
  }

  getOrdersByCustomerId(cid: number): Observable<Order[]> {
    return this.httpClient.get<Order[]>(`${this.orderApi}/customer/${cid}`);
  }

  deleteBYId(oid: number): Observable<Order> {
    return this.httpClient.delete<Order>(`${this.orderApi}/${oid}`);
  }

  add(order: Order): Observable<Order> {
    return this.httpClient.post<Order>(this.orderApi, order);
  }

  update(order: Order): Observable<Order> {
    return this.httpClient.put<Order>(this.orderApi, order);
  }
}
