import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from '../model/customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  // private _currentCustomer: Customer;
  custApi : string;

  constructor(private httpClient : HttpClient ) { 
    // this.currentCustomer=null;
    this.custApi = "http://localhost:8082/customers";
  }

  // get currentCustomer(){
  //   return this._currentCustomer;
  // }

  // set currentCustomer(cc:Customer){
  //   this._currentCustomer=cc;
  // }

  getAll() : Observable<Customer[]>{
    return this.httpClient.get<Customer[]>(this.custApi);
   }

   getById(cid : number) : Observable<Customer>{
     return this.httpClient.get<Customer>( `${this.custApi}/${cid}`);
   }

   deleteById(cid : number) : Observable<void>{
     return this.httpClient.delete<void>( `${this.custApi}/${cid}`);
   }

   add(customer : Customer) : Observable<Customer>{
     return this.httpClient.post<Customer>(this.custApi,customer);
   }

   update(customer : Customer) : Observable<Customer>{
    return this.httpClient.put<Customer>(this.custApi,customer);
  }
}
