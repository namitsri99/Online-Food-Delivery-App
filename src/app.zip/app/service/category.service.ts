import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { Category } from '../model/category';


@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  categoriesApi : string;

  constructor(private httpClient : HttpClient) {
    this.categoriesApi = "http://localhost:8082/categories";
   }

   getAll() : Observable<Category[]>{
    return this.httpClient.get<Category[]>(this.categoriesApi);
   }

   getById(catid : number) : Observable<Category>{
     return this.httpClient.get<Category>( `${this.categoriesApi}/${catid}`);
   }
   

  add(Category : Category) : Observable<Category>{
    return this.httpClient.post<Category>(this.categoriesApi,Category);
  }

  deleteById(catid : number) : Observable<void>{
    return this.httpClient.delete<void>( `${this.categoriesApi}/${catid}`);
  }

  update(Category : Category) : Observable<Category>{
   return this.httpClient.put<Category>(this.categoriesApi,Category);
 }

}