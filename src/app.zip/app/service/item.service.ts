import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Items } from '../model/items';

@Injectable({
  providedIn: 'root'
})
export class ItemService {

  itemsApi:string;

  constructor(private httpClient : HttpClient) {
    this.itemsApi="http://localhost:8082/items";
  }

  getAll() : Observable<Items[]>{
    return this.httpClient.get<Items[]>(this.itemsApi);
   }

   getById(itemId:number) : Observable<Items>{
    return this.httpClient.get<Items>(`${this.itemsApi}/${itemId}`);

  }

  deleteById(itemId:number) : Observable<void> {
    return this.httpClient.delete<void>(`${this.itemsApi}/${itemId}`);
  }
  add(item : Items) :Observable <Items>{
    return this.httpClient.post<Items>(this.itemsApi,item);
  }

  update(item :Items) : Observable<Items>{
    return this.httpClient.put<Items>(this.itemsApi,item);
  }
}