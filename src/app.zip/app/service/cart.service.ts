import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Cart } from '../model/cart';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  cartApi: string;
  
  constructor(private httpClient: HttpClient) {
    this.cartApi = "http://localhost:8082/carts";
  }

  getAll(): Observable<Cart[]>{
     return this.httpClient.get<Cart[]>(this.cartApi)
  }

  getById(cid: number): Observable<Cart> {
    return this.httpClient.get<Cart>(`${this.cartApi}/${cid}`);
  }

  getCartByCustomer(cid : number) : Observable<Cart> {
    return this.httpClient.get<Cart>(`${this.cartApi}/customer/${cid}`);
  }



  deleteBYId(cid: number): Observable<Cart> {
    return this.httpClient.delete<Cart>(`${this.cartApi}/${cid}`);
  }

  add(cart: Cart): Observable<Cart> {
    return this.httpClient.post<Cart>(this.cartApi, cart);
  }

  update(cart: Cart): Observable<Cart> {
    return this.httpClient.put<Cart>(this.cartApi, cart);
  }
}
