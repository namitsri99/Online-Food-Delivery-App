import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Bill } from '../model/bill';

@Injectable({
  providedIn: 'root'
})
export class BillService {
  billsApi : string;

  constructor(private httpClient : HttpClient) {
    this.billsApi = "http://localhost:8082/bills";
   }

   getAll() : Observable<Bill[]>{
    return this.httpClient.get<Bill[]>(this.billsApi);
   }

   getById(bid : number) : Observable<Bill>{
     return this.httpClient.get<Bill>(`${this.billsApi}/${bid}`);
   }
   
   getBillsByCustomer(cid : number) : Observable<Bill[]>{
     return this.httpClient.get<Bill[]>(`${this.billsApi}/customer/${cid}`);
   }

  add(bill : Bill) : Observable<Bill>{
    return this.httpClient.post<Bill>(this.billsApi,bill);
  }

  deleteById(bid : number) : Observable<void>{
    return this.httpClient.delete<void>( `${this.billsApi}/${bid}`);
  }

  update(bill : Bill) : Observable<Bill>{
   return this.httpClient.put<Bill>(this.billsApi,bill);
 }

}
