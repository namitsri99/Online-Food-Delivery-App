import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Order } from '../model/order';
import { OrderService } from '../service/order.service';

@Component({
  selector: 'app-user-order-details',
  templateUrl: './user-order-details.component.html',
  styleUrls: ['./user-order-details.component.css']
})
export class UserOrderDetailsComponent implements OnInit {

  userOrder : Order;
  err : string;
  constructor(private orderService : OrderService, private activatedRoute : ActivatedRoute ) { }

  ngOnInit(): void {
    let oid= this.activatedRoute.snapshot.params.oid;
    if(oid){
      this.orderService.getById(oid).subscribe(
        (data) => { this.userOrder=data; },
        (err) => { console.log (err); this.err = "sorry. unable to retrieve data"}
      )
    }

  }

}
