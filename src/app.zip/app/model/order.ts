export class Order {
    orderId: number;
    orderDate: Date;
    orderStatus: string;
    cartId : number;
}
