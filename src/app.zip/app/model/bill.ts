export class Bill {
    billId : number;
    orderId : number;
   totalItem : number;
   totalCost : number;
   billDate : Date;
   

}
