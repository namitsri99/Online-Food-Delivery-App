export class Items {
    itemId:number;
    itemName:string;
    catId : number;
    quantity:number;
    cost:number;
    cartId : number;
}