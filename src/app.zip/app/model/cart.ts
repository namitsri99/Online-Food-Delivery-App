export class Cart {
    cartId: number;
    customerId: number;
    
}

