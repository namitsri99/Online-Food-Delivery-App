export interface Login {
    userid : number;
    userName : string;
    password : string;
    customerId : number;
}



