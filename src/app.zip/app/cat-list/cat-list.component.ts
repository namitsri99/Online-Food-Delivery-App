import { Component, OnInit } from '@angular/core';
import { Category } from '../model/category';
import { CategoryService } from '../service/category.service';

@Component({
  selector: 'app-cat-list',
  templateUrl: './cat-list.component.html',
  styleUrls: ['./cat-list.component.css']
})
export class CatListComponent implements OnInit {
  categories : Category[];
  err : string;

  constructor(private categoryService : CategoryService) { }
 
  ngOnInit(): void {
    this.categoryService.getAll().subscribe(
      (data) => this.categories = data,
      (err) => { console.log (err); this.err = "sorry. unable to retrieve data"}
    );
  }

  delete(catId: number) {
    if (confirm("Are you sure?")) {
      this.categoryService.deleteById(catId).subscribe(
        () => { this.categories.splice(this.categories.findIndex(cat => cat.catId == catId), 1) }
      );
    }
  }

 
}
