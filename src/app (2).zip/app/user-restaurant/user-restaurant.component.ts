import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-restaurant',
  templateUrl: './user-restaurant.component.html',
  styleUrls: ['./user-restaurant.component.css']
})
export class UserRestaurantComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {}
    
}