import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-restaurant-id',
  templateUrl: './user-restaurant-id.component.html',
  styleUrls: ['./user-restaurant-id.component.css']
})
export class UserRestaurantIdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
