import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-user-customer',
  templateUrl: './user-customer.component.html',
  styleUrls: ['./user-customer.component.css']
})
export class UserCustomerComponent implements OnInit {


  constructor() {
    
   }

  ngOnInit(): void {
  }

}
