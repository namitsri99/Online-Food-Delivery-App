/*Members of this class are defined here*/
export class Category {
    catId : number;
    categoryName : string;
}

