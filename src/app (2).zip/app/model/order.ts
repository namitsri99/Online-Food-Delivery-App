/*Members of this class are defined here*/
export class Order {
    orderId: number;
    orderDate: Date;
    orderStatus: string;
    cartId : number;
}
