/*Members of this class are defined here*/
export class Bill {
    billId : number;
    orderId : number;
   totalItem : number;
   totalCost : number;
   billDate : Date;
   

}
