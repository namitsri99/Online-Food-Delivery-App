/*Members of this class are defined here*/
export class Address {
    buildingName: string;
    area : string;
    streetNo : string;
    city : string;
    state : string;
    country : string;
    pincode : string;
}
