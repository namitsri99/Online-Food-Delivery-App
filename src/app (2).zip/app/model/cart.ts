/*Members of this class are defined here*/
export class Cart {
    cartId: number;
    customerId: number;
    
}

