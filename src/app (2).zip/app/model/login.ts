/*Members of this class are defined here*/
export interface Login {
    userid : number;
    userName : string;
    password : string;
    customerId : number;
}



