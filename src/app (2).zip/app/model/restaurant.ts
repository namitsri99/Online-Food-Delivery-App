import { Address } from "./address";
/*Members of this class are defined here*/
export class Restaurant {
    restaurantId:number;
    restaurantName:string;
    itemId: number;
    managerName:string;
    contactNumber:number;
    address : Address;
    
    
}