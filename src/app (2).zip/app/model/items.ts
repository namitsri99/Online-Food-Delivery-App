/*Members of this class are defined here*/
export class Items {
    itemId:number;
    itemName:string;
    catId : number;
    quantity:number;
    cost:number;
    cartId : number;
}