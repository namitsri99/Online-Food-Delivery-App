import { Component, OnInit } from '@angular/core';
import { Restaurant } from '../model/restaurant';
import { RestaurantService } from '../service/restaurant.service';

@Component({
  selector: 'app-restaurant-list',
  templateUrl: './restaurant-list.component.html',
  styleUrls: ['./restaurant-list.component.css']
})
export class RestaurantListComponent implements OnInit {
  restaurants : Restaurant[];
  err:string;
  
  constructor(private restaurantsService :RestaurantService) { }

  ngOnInit(): void {
    this.restaurantsService.getAll().subscribe(
      (data) => this.restaurants = data,
      (err) => { console.log (err); this.err = "sorry. unable to retrieve data"}
    );
  }

  delete(rId: number) {
    if (confirm("Are you sure?")) {
      this.restaurantsService.deleteById(rId).subscribe(
        () => { this.restaurants.splice(this.restaurants.findIndex(r => r.restaurantId == rId), 1) }
      );
    }
  }

}