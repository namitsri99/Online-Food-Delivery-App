import { Component, OnInit } from '@angular/core';
import { Bill } from '../model/bill';
import { BillService } from '../service/bill.service';

@Component({
  selector: 'app-bill-list',
  templateUrl: './bill-list.component.html',
  styleUrls: ['./bill-list.component.css']
})
export class BillListComponent implements OnInit {
  bills : Bill[];
  err : string;

  constructor(private billService : BillService) { }
 
  ngOnInit(): void {
    this.billService.getAll().subscribe(
      (data) => this.bills = data,
      (err) => { console.log (err); this.err = "sorry. unable to retrieve data"}
    );
  }

  delete(bId: number) {
    if (confirm("Are you sure?")) {
      this.billService.deleteById(bId).subscribe(
        () => { this.bills.splice(this.bills.findIndex(b => b.billId == bId), 1) }
      );
    }
  }

}
