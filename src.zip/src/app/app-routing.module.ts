import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BillFormComponent } from './bill-form/bill-form.component';
import { BillListComponent } from './bill-list/bill-list.component';
import { BillComponent } from './bill/bill.component';
import { CartFormComponent } from './cart-form/cart-form.component';
import { CartListComponent } from './cart-list/cart-list.component';
import { CartComponent } from './cart/cart.component';
import { CatFormComponent } from './cat-form/cat-form.component';
import { CatListComponent } from './cat-list/cat-list.component';
import { CategoryComponent } from './category/category.component';
import { CustomerFormComponent } from './customer-form/customer-form.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CustomerComponent } from './customer/customer.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ItemFormComponent } from './item-form/item-form.component';
import { ItemListComponent } from './item-list/item-list.component';
import { ItemComponent } from './item/item.component';
import { OrderFormComponent } from './order-form/order-form.component';
import { OrderListComponent } from './order-list/order-list.component';
import { OrderComponent } from './order/order.component';
import { RestaurantFormComponent } from './restaurant-form/restaurant-form.component';
import { RestaurantListComponent } from './restaurant-list/restaurant-list.component';
import { RestaurantComponent } from './restaurant/restaurant.component';

const routes: Routes = [
  { path : 'dashboard', component : DashboardComponent },
  { path : 'customers', component : CustomerComponent, children : [
      { path : 'list', component : CustomerListComponent },
      { path : 'add', component : CustomerFormComponent },
      { path : 'edit/:eid', component : CustomerFormComponent },
      { path : '', redirectTo : 'list', pathMatch : 'full'}
] },

  { path : 'categories', component : CategoryComponent, children : [
    { path : 'list', component : CatListComponent },
    { path : 'add', component : CatFormComponent },
    { path : 'edit/:catid', component : CatFormComponent },
    { path : '', redirectTo : 'list', pathMatch : 'full'}
] },

  { path : 'carts', component : CartComponent, children : [
    { path : 'list', component : CartListComponent },
    { path : 'add', component :CartFormComponent },
    { path : 'edit/:cid', component : CartFormComponent },
    { path : '', redirectTo : 'list', pathMatch : 'full'}
] },

  { path : 'bills', component : BillComponent, children : [
    { path : 'list', component : BillListComponent },
    { path : 'add', component : BillFormComponent },
    { path : 'edit/:bid', component : BillFormComponent },
    { path : '', redirectTo : 'list', pathMatch : 'full'}
] },

  { path : 'items', component : ItemComponent, children : [
    { path : 'list', component : ItemListComponent },
    { path : 'add', component : ItemFormComponent },
    { path : 'edit/:iid', component : ItemFormComponent },
    { path : '', redirectTo : 'list', pathMatch : 'full'}
] },

{ path : 'orders', component : OrderComponent, children : [
  { path : 'list', component : OrderListComponent },
  { path : 'add', component : OrderFormComponent },
  { path : 'edit/:oid', component : OrderFormComponent },
  { path : '', redirectTo : 'list', pathMatch : 'full'}
] },
  { path : 'restaurants', component : RestaurantComponent, children : [
      { path : 'list', component : RestaurantListComponent },
      { path : 'add', component : RestaurantFormComponent },
      { path : 'edit/:rid', component : RestaurantFormComponent },
      { path : '', redirectTo : 'list', pathMatch : 'full'}
] },

  { path : '', redirectTo : 'dashboard' , pathMatch : 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
