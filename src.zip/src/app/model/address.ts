export class Address {
    buildingName: string;
    area : string;
    streetNo : string;
    city : string;
    state : string;
    country : string;
    pincode : string;
}
