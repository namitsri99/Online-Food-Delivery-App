import { Address } from "./address";

export class Restaurant {
    restaurantId:number;
    restaurantName:string;
    itemId: number;
    managerName:string;
    contactNumber:number;
    address : Address;
    
    
}